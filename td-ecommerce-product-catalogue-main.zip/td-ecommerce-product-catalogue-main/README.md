# eCommerce Product Catalogue

In this project, you will be asked to add interactivity to an existing web page. You will use javascript to toggle hamburger menu on mobile screens, display products based on category selected and display product items that matches the user search input field. 