// ==================================
// 1. Toggle humbugger menu;
// By default, the .link tag should 
// display none.
// ==================================






// ==================================
// 2. Display products based on 
// All, Men or Female categories.
// ==================================






// ==================================
// 2. Display products based on 
// search keywords in the input fields.
// ==================================